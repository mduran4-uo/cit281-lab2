/* 
CIT 281 Lab 2
*/

function square(num) {
    return num*num;
}
console.log('Square operations:')
for (let i = 2; i <= 10; i+=2) {
    console.log(`Square of ${i} is ${square(i)}`);
}
let x = 2;
x += 1;
console.log(x);

// This is a comment
console.log(`Square of 20 is ${square(10)}`);